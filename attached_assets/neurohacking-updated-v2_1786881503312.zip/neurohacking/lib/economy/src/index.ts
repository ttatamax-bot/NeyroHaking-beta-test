/**
 * Единый источник правды по экономике приложения.
 *
 * Модель (ТЗ «обновление экономики»):
 * - Потенциал дня: шкала 0–100%, обнуляется каждый новый день приложения.
 * - Любая техника, кроме Планера: +10% за одно выполнение, длительность не влияет.
 * - Планер: базовый потенциал по таблице фактического времени × коэффициент точности.
 * - Ключи начисляются только за закрытие дня на 100%: 100 + 25 × (день серии − 1), максимум 450.
 * - Серия — количество подряд закрытых на 100% дней.
 */

export type TechniqueId = "T1" | "T2" | "T3" | "T4" | "T5" | "T6";

export const TECHNIQUE_IDS: TechniqueId[] = ["T1", "T2", "T3", "T4", "T5", "T6"];

/** Планер. Остальные техники дают фиксированный потенциал. */
export const PLANNER_TECHNIQUE_ID: TechniqueId = "T1";

/** Потенциал за одно выполнение обычной техники, в процентах. */
export const TECHNIQUE_POTENTIAL_PERCENT = 10;

/** Потолок потенциала дня, в процентах. */
export const DAY_POTENTIAL_TARGET = 100;

/** Награда за первый день серии, в ключах. */
export const DAY_CLOSE_BASE_KEYS = 100;

/** Прирост награды за каждый следующий день серии. */
export const DAY_CLOSE_STEP_KEYS = 25;

/** Максимальная награда за закрытый день (с 15-го дня серии). */
export const DAY_CLOSE_MAX_KEYS = 450;

/** День серии, с которого награда перестаёт расти. */
export const DAY_CLOSE_MAX_STREAK_DAY = 15;

/** Базовый потенциал Планера: [фактические минуты, проценты]. */
export const PLANNER_POTENTIAL_TABLE: ReadonlyArray<readonly [number, number]> = [
  [10, 3],
  [15, 5],
  [30, 10],
  [60, 20],
  [90, 30],
  [120, 40],
  [150, 48],
  [180, 55],
  [210, 60],
  [240, 65],
  [270, 68],
  [300, 71],
  [330, 74],
  [360, 77],
  [390, 80],
  [420, 83],
  [450, 86],
  [480, 90],
];

/** Базовый потенциал Планера по фактическому времени, в процентах. */
export function plannerBasePotential(actualMinutes: number): number {
  if (!Number.isFinite(actualMinutes) || actualMinutes <= 0) return 0;
  const first = PLANNER_POTENTIAL_TABLE[0]!;
  const last = PLANNER_POTENTIAL_TABLE[PLANNER_POTENTIAL_TABLE.length - 1]!;
  if (actualMinutes < first[0]) return (first[1] * actualMinutes) / first[0];
  if (actualMinutes >= last[0]) return last[1];
  for (let i = 0; i < PLANNER_POTENTIAL_TABLE.length - 1; i += 1) {
    const [lowMinutes, lowPercent] = PLANNER_POTENTIAL_TABLE[i]!;
    const [highMinutes, highPercent] = PLANNER_POTENTIAL_TABLE[i + 1]!;
    if (actualMinutes >= lowMinutes && actualMinutes < highMinutes) {
      const ratio = (actualMinutes - lowMinutes) / (highMinutes - lowMinutes);
      return lowPercent + (highPercent - lowPercent) * ratio;
    }
  }
  return 0;
}

/** Коэффициент точности оценки времени Планера. */
export function plannerAccuracy(actualSeconds: number, estimatedSeconds: number): number {
  if (actualSeconds <= 0 || estimatedSeconds <= 0) return 0;
  const deviation =
    Math.abs(actualSeconds - estimatedSeconds) / Math.max(actualSeconds, estimatedSeconds);
  return Math.exp(-1.5 * deviation * deviation);
}

/** Итоговый потенциал Планера, в процентах (с точностью до 0.1%). */
export function plannerPotential(actualSeconds: number, estimatedSeconds: number): number {
  if (actualSeconds <= 0 || estimatedSeconds <= 0) return 0;
  // Переработка сверх оценки не увеличивает базу — она только снижает точность.
  const effectiveMinutes = Math.min(actualSeconds, estimatedSeconds) / 60;
  const base = plannerBasePotential(effectiveMinutes);
  const value = base * plannerAccuracy(actualSeconds, estimatedSeconds);
  return Math.round(value * 10) / 10;
}

/** Потенциал за выполнение техники, в процентах. */
export function potentialForTechnique(
  techniqueId: TechniqueId,
  metadata: Record<string, unknown> = {},
): number {
  if (techniqueId === PLANNER_TECHNIQUE_ID) {
    const actualSeconds = Number(metadata['actualSeconds'] ?? 0);
    const estimatedSeconds = Number(metadata['estimatedSeconds'] ?? 0);
    if (!Number.isFinite(actualSeconds) || !Number.isFinite(estimatedSeconds)) return 0;
    // Слишком ранняя остановка таймера не считается выполнением.
    if (actualSeconds < estimatedSeconds * 0.3) return 0;
    return plannerPotential(actualSeconds, estimatedSeconds);
  }
  return TECHNIQUE_POTENTIAL_PERCENT;
}

/** Награда в ключах за закрытие дня на 100% для указанного дня серии. */
export function dayCloseReward(streakDay: number): number {
  if (!Number.isFinite(streakDay) || streakDay <= 0) return 0;
  if (streakDay >= DAY_CLOSE_MAX_STREAK_DAY) return DAY_CLOSE_MAX_KEYS;
  return DAY_CLOSE_BASE_KEYS + DAY_CLOSE_STEP_KEYS * (streakDay - 1);
}

/** Ограничение отображаемого потенциала дня. */
export function clampDayPotential(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return 0;
  return Math.min(DAY_POTENTIAL_TARGET, Math.round(value * 10) / 10);
}

/** День закрыт, если потенциал достиг 100%. */
export function isDayClosed(dayPotential: number): boolean {
  return dayPotential >= DAY_POTENTIAL_TARGET;
}
