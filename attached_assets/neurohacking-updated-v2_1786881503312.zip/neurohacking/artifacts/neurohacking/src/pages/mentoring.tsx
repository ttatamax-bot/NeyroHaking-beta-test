import { ScreenTransition } from "@/components/ScreenTransition";
import { BackButton } from "@/components/BackButton";
import { Users } from "lucide-react";
import { motion } from "framer-motion";

// Покупка личного ведения удалена: страница осталась информационной,
// связаться можно только напрямую в Telegram.
const TG_CONTACT = "https://t.me/Mtatarinov?text=%D0%9F%D1%80%D0%B8%D0%B2%D0%B5%D1%82.%20%D0%A5%D0%BE%D1%87%D1%83%20%D1%83%D0%B7%D0%BD%D0%B0%D1%82%D1%8C%20%D0%BF%D0%BE%D0%B4%D1%80%D0%BE%D0%B1%D0%BD%D0%B5%D0%B5%20%D0%BE%20%D0%BB%D0%B8%D1%87%D0%BD%D0%BE%D0%BC%20%D0%B2%D0%B5%D0%B4%D0%B5%D0%BD%D0%B8%D0%B8.";

export default function Mentoring() {
  return (
    <ScreenTransition className="pt-[56px] px-4 pb-24 flex flex-col min-h-screen relative">
      <BackButton />

      <div className="flex-1 mt-4">
        <div className="flex items-center gap-3 mb-6">
          <div
            className="w-12 h-12 rounded-[14px] flex items-center justify-center"
            style={{ background: 'rgba(37,99,235,0.15)', border: '1px solid rgba(37,99,235,0.25)' }}
          >
            <Users size={24} color="#60A5FA" />
          </div>
          <h1 className="title-l text-primary">Личное ведение</h1>
        </div>

        <div className="space-y-4 body text-secondary leading-relaxed mb-8">
          <p>Месячная системная работа под моим личным контролем.</p>
          <p>Я лично проверяю твое выполнение техник, корректирую цели и не даю мозгу соскочить с новой траектории.</p>
          <p>Формат подходит тем, кому нужна максимальная ответственность и быстрый результат.</p>
        </div>

        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => window.open(TG_CONTACT, '_blank')}
          className="w-full rounded-[16px] p-4 text-left active:brightness-110 transition-all"
          style={{ background: 'rgba(37,99,235,0.12)', border: '1px solid rgba(37,99,235,0.3)' }}
        >
          <p className="title-s text-primary">Написать в Telegram</p>
          <p className="caption text-secondary">Обсудить формат и условия</p>
        </motion.button>
      </div>
    </ScreenTransition>
  );
}
